import java.util.Random;
public class Aula {
	
private String nombre;
Ordenador [] vecOrdenadores;
Ticket [] historial;


	Aula(String n,int nor){
		nombre=n;
		vecOrdenadores=new Ordenador[nor];
		historial=new Ticket[nor];
	}


	public int getNordenadores(){
		return vecOrdenadores.length;
	}

	public String getNombre(){
		return nombre;
	}

	public boolean desinstalarPc(Ordenador pc){
		boolean b=false;
		String id=pc.getId();
		for (int i = 1; i < vecOrdenadores.length-1; i++)
			if(vecOrdenadores[i]!=null && vecOrdenadores[i].getId().equals(id))
				vecOrdenadores[i]=null;
				
		return b;
	}

	public boolean instalarPc(Ordenador pc){
		boolean b=false;
		boolean apuntado=false;
		/*pongo i=1 porque en el vector el 0 es el del profesor y eso no se puede desisntalar si instalar*/
		for (int i = 1; i < vecOrdenadores.length-1; i++)
			if(vecOrdenadores[i]==null && apuntado==false){
				vecOrdenadores[i]=pc;
				apuntado=true;
				b=true;
			}
			
			return b;
	}

	private String generarIdTicketAleatoria(){
		String caracteres="ABCDEFGHIJKLMNOPQRSTUWXYZVabcdefghijklmnopqrstuvwxyz";
		boolean booleano=true;
		Random rnd=new Random();
		String n="";
		String completa="";
		boolean repetido=true;
		while(repetido==true){
			for (int i = 0; i < historial.length; i++)
			{
				n=caracteres.charAt(rnd.nextInt(caracteres.length()))+"";
				completa+=n;
			}
			repetido=RepiteId(completa);
			
		}
		return completa;
	}

	private boolean RepiteId(String id){
		boolean r=false;
		for (int i = 0; i < historial.length; i++)
			if(historial[i]!=null && historial[i].getIdTicket().equals(id))
				r=false;
				
		return r;
	}

	public boolean CrearTicket(Ordenador o){
		boolean apuntado=false;
		if(o!=null){
			Ticket temp=new Ticket(generarIdTicketAleatoria(),this.nombre,o);
			for (int i = 0; i < historial.length; i++)
				if (historial[i]==null && apuntado==false){
					historial[i]=temp;
					apuntado=true;
				}
				System.out.println(temp.toString());
		}
		return apuntado;
	}

public static void main (String[] args) {
		Aula a=new Aula("aula12",25);
		Ordenador o=new Ordenador("j","h0",23,23,true);
		a.CrearTicket(o);
	}


	public String toString(){
		String temp="";
		String temp2="";
		for (int i = 0; i < vecOrdenadores.length; i++)
			if(vecOrdenadores[i]!=null)
				temp+=vecOrdenadores[i];
				
		for (int i = 0; i < vecOrdenadores.length; i++)
			if(historial[i]!=null)
				temp2+=historial[i];
				
		
		return "\nnombre del aula: "+nombre+"\nOrdenadores\n"+temp+"\nHistorial de tickets\n"+temp2;
	}


}

