
public class AulaVIP extends Aula{
	
private String proyector;
private boolean Aire;

AulaVIP(String n,int nor,String proyector,boolean b){
	super(n,nor);
	this.proyector=proyector;
	Aire=b;
}
	
	
	
}

