
public class Centro {
	private String nombre;
	Aula [] Aulas ;
	
	Centro(String n,int e){
		nombre=n;
		Aulas=new Aula[e];
	}
	
	Centro(int e){
		Aulas=new Aula[e];
	}	
	public boolean InsertarAula(Aula a){
	boolean apuntado=false;
	for (int i = 0; i < Aulas.length; i++)
		if (Aulas[i]==null && apuntado==false)
		{
			Aulas[i]=a;
			apuntado=true;
		}

		return apuntado;
	}
}

