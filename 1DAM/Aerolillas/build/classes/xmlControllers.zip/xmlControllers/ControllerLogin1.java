/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xmlControllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Angel
 */
public class ControllerLogin1 {
    
    @FXML
    private Label labelNo;
    @FXML
    private TextField inputPassword;
    @FXML
    private TextField inputUsuario;
    @FXML
    private Button botonInicioSesion;
    @FXML
    private Button botonAnterior2;
    @FXML
    private Button botonIrRegistro;
    
    
}
