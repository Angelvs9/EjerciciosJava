﻿Public Class Palindromo

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn.Click
        lblNo.Visible = False
        lblSi.Visible = False
        Dim frase As String
        Dim temp As String = ""
        Dim temp2 As String = ""
        Dim palindromo As Boolean = False
        frase = txt.Text
        For i As Integer = 0 To frase.Length - 1
            If frase(i) <> " " Then
                temp = temp & frase(i) & ""
            End If
        Next
        For i As Integer = frase.Length - 1 To 0 Step -1
            If frase(i) <> " " Then
                temp2 = temp2 & frase(i) & ""
            End If
        Next
        If temp.Equals(temp2) Then
            palindromo = True
        Else
            palindromo = False
        End If
        REM ya para activar la visibilidad de una o otra segun sea o no palindromo 
        If palindromo = True Then
            lblSi.Visible = True
        Else
            lblNo.Visible = True
        End If


    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label.Click

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt.TextChanged

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblNo.Click

    End Sub

    Private Sub Label1_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblSi.Click

    End Sub
End Class
