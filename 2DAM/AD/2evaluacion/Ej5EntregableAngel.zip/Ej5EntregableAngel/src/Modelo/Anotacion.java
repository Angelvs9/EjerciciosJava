
package Modelo;

/**
 *
 * @author Angel
 */
public class Anotacion {
    
}
